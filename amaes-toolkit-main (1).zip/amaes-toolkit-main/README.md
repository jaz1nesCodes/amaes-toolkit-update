<p align="center">
  <img src="assets/amaes-toolkit-logo.png" alt="AMAES Toolkit Logo" width="120" height="120">
</p>

<h1 align="center">AMAES Toolkit</h1>

<p align="center">
  <b>Universal Assistive Study Toolkit & Offline Question Bank for Moodle Portals</b><br>
  <span>Designed for students on <code>semestral.amaes.com</code></span>
</p>

<p align="center">
  <a href="https://raw.githubusercontent.com/Acads-Tools/amaes-toolkit/main/amaes-toolkit.user.js"><img src="https://img.shields.io/badge/version-1.13.9-blue.svg" alt="Version 1.13.9"></a>
  <a href="https://amaestoolkit.pages.dev/"><img src="https://img.shields.io/badge/platform-Violentmonkey%20%7C%20Tampermonkey-darkblue.svg" alt="Platform Compatibility"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-yellow.svg" alt="License: MIT"></a>
  <a href="#zero-telemetry--privacy-architecture"><img src="https://img.shields.io/badge/privacy-zero--telemetry-success.svg" alt="Zero Telemetry"></a>
  <a href=".github/workflows/privacy-check.yml"><img src="https://img.shields.io/badge/privacy--audit-passing-brightgreen.svg" alt="Privacy Check Passed"></a>
</p>

<p align="center">
  <a href="https://amaestoolkit.pages.dev/"><strong>Open Fast Web Installer: https://amaestoolkit.pages.dev</strong></a>
</p>

> [!IMPORTANT]
> **Compatibility Notice:** Version **1.13.0** is the active supported release. Older clients are blocked at startup and must be updated via Violentmonkey or the [official userscript link](https://raw.githubusercontent.com/Acads-Tools/amaes-toolkit/main/amaes-toolkit.user.js). Review [CLIENT-COMPATIBILITY.md](docs/CLIENT-COMPATIBILITY.md) for full version lifecycle policies.

---

<p align="center">
  <img src="assets/amaes-toolkit-live-demo.gif" alt="AMAES Toolkit Live Interface Demo" width="100%" style="border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,0.25);">
  <br>
  <em>Live in-quiz assistance: visual answer highlighting, autonomous progress guard, and in-question banner controls.</em>
</p>

---

## Table of Contents
* [Prerequisites & Supported Environment](#prerequisites--supported-environment)
* [Key Features](#features)
* [Usage & Features Deep-Dive](#usage--features-deep-dive)
  * [4-Tier Answer Intelligence](#4-tier-answer-intelligence)
  * [Multi-Course Grades Harvester](#multi-course-grades-harvester-batch-scanner)
  * [Autonomous Solver vs Companion Mode](#autonomous-solver-vs-companion-mode)
  * [Activity Auto-Marker & Passable Grade Guard (≥ 80%)](#activity-auto-marker--passable-grade-guard--80)
* [Installation & Setup](#installation--setup)
* [Keyboard Shortcuts](#keyboard-shortcuts)
* [Developer & Contributing Guide](#developer--contributing-guide)
  * [Forking & Adapting for Other Moodle Portals](#forking--adapting-for-other-moodle-portals)
* [Zero Telemetry & Privacy Architecture](#zero-telemetry--privacy-architecture)
* [Frequently Asked Questions](#frequently-asked-questions)
* [Academic Integrity & Liability Disclaimer](#academic-integrity--liability-disclaimer)

---

<a id="prerequisites--supported-environment"></a>

## Prerequisites & Supported Environment

Before installing, ensure your environment meets the following specifications:

| Requirement | Supported Specifications | Notes |
| :--- | :--- | :--- |
| **Supported Browsers** | Google Chrome (v110+), Brave, Microsoft Edge, Mozilla Firefox, Opera | Chromium browsers require "Developer mode" enabled in extensions. |
| **Userscript Manager** | **[Violentmonkey](https://violentmonkey.github.io/)** (Strongly Recommended) or Tampermonkey | Violentmonkey provides the cleanest User Scripts API compatibility. |
| **Target Moodle Portal** | `https://semestral.amaes.com/*` | Supports root domains and specific term subpaths (e.g., `/2612/`). |
| **Network Access** | Unrestricted access to `semestral.amaes.com` and GitHub raw content | Institutional firewall restrictions may block userscript auto-updates. |

---

<a id="features"></a>

## Features

### 1. Real-Time Answer Verification & Auto-Quiz Assistance
* **Visual Answer Highlighting:** Automatically matches quiz questions against verified ground truth and highlights correct choices in clean green indicators.
* **Autonomous Progression (`Auto-Next`):** Automatically selects verified answers and smoothly advances to the next question.
* **Autonomous Background Execution:** Runs hands-free across questions and pages in background tabs while multitasking. Fully un-gated progression ensures the solver does not freeze or pause when questions are answered via verified database matches, Jenny's Online / AMAUOED study-guide candidates, adaptive choice probing, or Gemini AI.
* **Landing Page 1-Click Auto-Arming:** Clicking "Start Auto-Quiz" directly on the quiz introduction page (`/mod/quiz/view.php`) arms the engine in advance, so answer resolution and page transitions begin immediately upon quiz attempt load.
* **Online Study Guides (AMAUOED & Jenny's Online):** Study Library features dedicated status pills, course match indicators, and 1-click link copying for Jenny's Online study guides alongside AMAUOED.
* **Smart Dashboard Course Detection:** Eliminates false-positive subject mismatch alerts when browsing the Moodle dashboard by verifying active course context before displaying warnings.
* **Ground-Truth Safety Gate:** Only Moodle-confirmed answers are auto-selected or auto-filled. AMAUOED and Jenny's Online suggestions remain clearly labeled and require manual selection, even when Auto-Pick is enabled.
* **Source Confidence Labels:** Jenny's Online and AMAUOED are equal-priority study-guide suggestions, not verified answers; only Moodle review evidence, a matching 100% attempt, or explicit review-backed deduction can confirm an answer. An overall quiz score alone never proves which question was right or wrong.
* **Non-Reviewable Quiz Safety:** A 100% overall score is not used to verify or share individual answers when Moodle explicitly blocks review or review permission cannot be confirmed. GE6301 (Gender and Society) is designated non-reviewable: its shared verified answer bank is cleared, answer sharing is blocked locally and at the relay, while unverified study-guide/AI suggestions remain separate. Other explicit restrictions are reported using only the course code and a random anonymous installation ID, hashed before database storage; shared warnings require three distinct installations within 90 days.
* **Course-Aware Guide Discovery:** AMAUOED discovery uses the detected course name when available. Jenny's Online is scraped by the database refresh job, not by quiz-page code.
* **Study-Guide Data Safety:** Jenny's shared database snapshot is the source of truth and includes its last refresh timestamp. The toolkit uses snapshots younger than 30 days, returns cached/stale suggestions while queuing a refresh for stale or missing data, and rechecks the shared snapshot during the same session. The database scrapes Jenny monthly and can also refresh an individual course on demand. AMAUOED and Jenny remain separate, equally prioritized, and unconfirmed.
* **Unreviewable Retry Warning:** On quiz pages that prohibit review, the toolkit warns that a later attempt may score lower and that a quiz-wide score is not evidence about individual answers.
* **Live In-Question Controls:** Pause or resume automated assistance directly from the top banner inside any question without closing your workflow.

### 2. Comprehensive Question Type Support
* **Multiple Choice & Multi-Select:** Accurately identifies single-answer choices and multi-answer checkbox groups, ensuring all verified options are checked before proceeding.
* **True / False:** Dedicated ground-truth deduction and option selection.
* **Short Answer & Fill-in-the-Blank (Cloze):** Identifies inline input blanks, normalizes text, and provides 1-click interactive fill hints.
* **Interactive Dropdowns & Matching:** Resolves matching table dropdowns and gap-select options.
* **Drag-and-Drop:** Highlights available choices, marks drop zones, and provides 1-click token placement.

### 3. Multi-Course Grades Harvester (Batch Scanner)
* **One-Click Historical Review:** Scans your completed past quiz attempts from Moodle grade reports and catalogs 100% verified answers into your offline database.
* **Elimination Learning:** Automatically records choices confirmed wrong in past attempts, ensuring you never select known incorrect answers again.
* **Dashboard Badges:** Injects live coverage pills (e.g., `45 Verified Answers Cached`) onto course cards on the Moodle homepage.

### 4. Built-in Google Gemini AI Assistant (Experimental) & Study Tools
* **Native In-Quiz AI Solver:** Directly answers uncertain Multiple Choice and True/False questions in real time using Google Gemini via a free personal Google AI Studio API key.
* **Session Answer Caching:** Once an answer is suggested or selected by AI, it is cached for that question during the active quiz session. Navigating back and forth between questions instantly restores the choice with **0 API requests and 0 token cost**.
* **Confirmed Wrong Answer Elimination Guard:** Choices confirmed as incorrect by the database or previous attempts are annotated in the AI prompt (`[CONFIRMED WRONG - DO NOT SELECT]`) and hard-blocked by solver guards. If only 1 valid alternative remains, the toolkit deduces it automatically.
* **Configurable Retry Attempts:** Easily configure AI retry attempts (1 to 5, default: **2 retries**) directly from Quiz tab settings or Course Tools.
* **Auto-Copy Question on AI Failure:** Toggleable option (default: **ON**) that automatically copies the formatted question to clipboard if AI times out or fails, enabling immediate `Ctrl+V` pasting into external AI models.
* **Token-Conservation Architecture:** Strictly triggers only on questions without confirmed answers in the database, consuming **0 tokens** on known questions.
* **Auto-Select or Suggestion Review:** Choose between automated choice selection or visual highlighting with an `AI Suggestion (Gemini)` badge and purple outline for manual confirmation.
* **Watchdog Timer & Safe Fallbacks:** 8-second timeout, interactive cancel button, and an in-question fallback bar with `Retry AI` and `Copy for AI`. Complex formats (drag-and-drop, dropdown matching, short answers) automatically fall back to manual copy.
* **Instant Keystroke Shortcuts:**
  * `C`: Formats the active question, choices, and instructions ready for your preferred AI tool.
  * `V`: Automatically parses clipboard content and selects matching choices or fills text inputs in the browser.

### 5. Course Tools: Activity Auto-Marker & Passable Grade Guard (≥ 80%)
* **Lecture & Video Batch Completer:** Automatically checks off asynchronous lectures and video activities with 1 click.
* **Strict Passable Grade Safety Guard (≥ 80%):** When marking quizzes or clicking "Mark ALL as Done", the toolkit strictly verifies your actual score via the Moodle Grade Report (`/grade/report/user/index.php`) and activity completion markers.
  * **Passable (≥ 80%):** Quizzes and exams with a recorded grade of 80% or higher (or marked as passed) are safely marked as done.
  * **Under 80% / Failing (< 80%):** Quizzes with scores below 80% or marked as failed are strictly skipped and left untouched.
  * **Unattempted / No Grade:** Quizzes that have not yet been taken or have no recorded score are strictly skipped and left untouched, ensuring you never accidentally bypass an assessment.
* **Live Audit Log:** Displays verified percentages in real time (e.g. `[1/3] Marking: Quiz 1... [90%]`) and reports clear safety warnings when unpassed quizzes remain protected.
* **Fast Account Switcher:** Optionally save an account from the Moodle login page, then use its nickname as a quick sign-in button on later login pages or switch from Course Tools. Edit or remove saved accounts and see which saved nickname matches the current Moodle profile. Credentials remain unencrypted in local userscript-manager storage.
* **Encrypted Setup Transfer:** From Course Tools, create a one-time code to transfer selected toolkit preferences (automation, AI, appearance, and panel layout), saved Moodle profiles, and Gemini API keys to another device. Data is encrypted in your browser before upload; the relay stores ciphertext until it is imported, then deletes it. Codes do not expire but can be consumed only once. The code is a secret: anyone who gets it can import the selected credentials. Service tokens, Moodle sessions, caches, and installation identity are not transferred. Imported credentials remain unencrypted in the destination browser's local storage.

### 6. Autonomous Web Scraper Fallback Engine
* **Background Study Search:** When an answer is missing from the local database, the toolkit searches online study guides and presents clearly labeled, unconfirmed suggestions for manual review.

### 7. Privacy-Safe Community Synchronization
* **Automatic Course Bank Loading:** Automatically fetches verified questions for your active subject directly from the open study database ([`Acads-Tools/database`](https://github.com/Acads-Tools/database)) upon opening Moodle.
* **Consensus-Driven Question Sharing:** Confirmed review answers from completed quiz attempts are pooled anonymously to expand coverage for fellow students.
* **Review Elimination Sharing:** Moodle-confirmed incorrect choices are saved locally and sent as elimination evidence, even when the review does not reveal the correct answer. Failed relay requests remain eligible for retry; accepted reports still pass through automated validation before entering the shared database.
* **Privacy by Default:** Student names, student IDs, email addresses, grades, and Moodle session tokens are not collected for telemetry, community answers, or study services. Account Switcher details stay in userscript-manager storage on your device; usernames and passwords are not encrypted at rest, so anyone with access to your browser profile may be able to view them. Credentials are only submitted to Moodle's own login form unless you explicitly opt in to an encrypted one-time setup transfer. If selected, account usernames/passwords and API keys are sent only inside browser-encrypted ciphertext; the relay cannot read them. The ciphertext is retained until the transfer is consumed, and the code does not expire but works once only. Anyone who obtains the code can import the selected credentials. Saving from the login page is optional and occurs only when you check the save box.

---

<a id="usage--features-deep-dive"></a>

## Usage & Features Deep-Dive

### 4-Tier Answer Intelligence
The toolkit evaluates every question through a 4-tier verification hierarchy to maximize accuracy and safety:

```mermaid
flowchart TD
    Q["Quiz Question Detected"] --> T1{"Tier 1: Local Review Key"}
    T1 -- Found Full Mark Ground Truth --> V1["Highlight Green Verified<br>(Confidence: 100%)"]
    T1 -- Not in Local Cache --> T2{"Tier 2: Community Consensus Bank"}
    T2 -- Found in Cloud Database --> V2["Highlight Blue Verified<br>(Confidence: 95%+)"]
    T2 -- Not in Community DB --> T3{"Tier 3: Online Study Guides (AMAUOED & Jenny's Online)"}
    T3 -- Found in Web Guide --> V3["Highlight Amber Warning<br>(Scraped from Student Guide)"]
    T3 -- No Online Match --> T4{"Tier 4: Google Gemini AI"}
    T4 -- AI Key Configured --> V4["Highlight Purple AI Suggestion<br>(or Auto-Pick if Enabled)"]
    T4 -- AI Disabled / Failed --> S["Safety Gate: Pause for Manual Review<br>(Press C to Copy for AI)"]
```

1. **Tier 1 (Local Verified Review Key - 100% Ground Truth):** Scraped directly from your own graded quizzes scoring 1.00/1.00. Marked with a green checkmark pill.
2. **Tier 2 (Community Verified Consensus Bank):** Merged from anonymous peer review keys via [`Acads-Tools/database`](https://github.com/Acads-Tools/database).
3. **Tier 3 (Online Study Guides - AMAUOED & Jenny's Online):** Checks cached student study guides when the local library has no match. Marked with an amber unverified candidate badge.
4. **Tier 4 (Google Gemini AI Engine):** Solves remaining Multiple Choice or True/False questions on-the-fly. Marked with an `AI Suggestion` purple pill.

### Multi-Course Grades Harvester (Batch Scanner)
The Grades Harvester allows you to quickly build an answer library for all your enrolled subjects by scanning past graded quizzes in seconds.

* **How it Works:** Rather than manually opening every quiz, the Harvester visits Moodle's User Grade Report (`/grade/report/user/index.php`), inspects all completed attempts that scored full marks, and saves confirmed answers into your offline `localStorage`.
* **How to Trigger:**
  * **Automatic:** Runs silently once per session when viewing your Moodle Dashboard (`/my/`) or course homepages.
  * **Manual Trigger:** Open the toolkit panel > **Database** tab > click **Sync & Scan Past Quizzes**.

### Autonomous Solver vs Companion Mode
The toolkit offers two distinct operational modes depending on your preference:

* **Companion Mode (Default):** Highlights verified choices visually on screen but **never clicks or advances automatically**. You retain 100% control of every choice and button click.
* **Autonomous Auto-Quiz Solver:** Selects verified answers and clicks "Next page" automatically in background tabs.
  * **How to Enable:** In the **Quiz** tab, toggle **Auto-Quiz Mode: ON** (or press keyboard shortcut `P`), or click **Start Auto-Quiz** directly from the quiz introduction landing page.
  * **Hands-Free Background Execution:** Answers questions and advances smoothly without freezing. Fully un-gated progression ensures resolved questions do not stall automation.
  * **Safety Gate:** If a question has no confirmed answer and AI cannot resolve it, the solver pauses automatically, brings up the in-question toolbar, and sounds a gentle intervention chime.
* **Built-in Fast Answer Acceleration:**
  * **What it does:** Reduces the toolkit's post-answer navigation delay to **200ms** and enables 1-click batch solving for visible questions. Locally cached verified answers are checked first; optional online study-guide refreshes run in the background without accelerating Moodle's page/network response or turning unconfirmed suggestions into auto-answers.
  * **Multi-Question Pages:** Adds a 1-click **"Fill Verified Answers"** button that selects all verified answers on the current page simultaneously in 0.1s. If unknown questions remain and AI is enabled, it resolves them concurrently in parallel.
  * **Built-in by Default:** Operates out of the box with zero setup required.

### Activity Auto-Marker & Passable Grade Guard (≥ 80%)
Located in the **Course Tools** tab under **Activity Auto-Marker**, this utility automates course completion tracking while strictly enforcing academic safety:

* **Strict 80% Passable Threshold:**
  * When clicking **Mark Quizzes / Exams Only** or **Mark ALL as Done**, the toolkit checks the student's actual grades via `fetchCourseGradesMap` (reading Moodle's user grade report) and activity completion markers via `evaluateQuizPassableGrade`.
  * **Passed (≥ 80%):** Quizzes and exams with a recorded grade of 80% or higher (or marked as passed) are safely marked as done.
  * **Under 80% / Failing (< 80%):** Quizzes with scores below 80% or marked as failed are strictly skipped and left untouched.
  * **Unattempted / No Grade:** Quizzes that have not yet been taken or have no recorded score are strictly skipped and left untouched. This ensures upcoming assessments are never closed or bypassed prematurely.
* **Live Audit Log:** Each processed quiz displays its verified score percentage in the status log (e.g., `[1/3] Marking: Quiz 1... [90%]`). If no quizzes meet the passing threshold, an explanatory warning confirms that failing and unattempted quizzes remained untouched for student protection.
* **Full Reversibility:** Granular undo buttons (**Undo Lectures & Vids**, **Undo Quizzes / Exams**, **Undo ALL**) are provided to revert any activity completion state whenever needed.

---

<a id="installation--setup"></a>

## Installation & Setup

### Step 1: Install a Userscript Manager (Violentmonkey Recommended)
Install the **[Violentmonkey](https://violentmonkey.github.io/)** extension for your browser:

* **Google Chrome / Brave:**
  1. Install Violentmonkey from the [Chrome Web Store](https://chromewebstore.google.com/detail/violentmonkey/jinjaccalgkegednnccohejagnlnfdag).
  2. Open `chrome://extensions` in your address bar (or click the Extensions icon in your browser toolbar).
  3. In the top-right corner, toggle **Developer mode** to **ON**.
  4. Under Violentmonkey, ensure **Allow access to user scripts** is turned **ON**.
  5. Pin Violentmonkey to your browser toolbar for quick access.

* **Mozilla Firefox:**
  1. Install Violentmonkey from [Firefox Add-ons](https://addons.mozilla.org/en-US/firefox/addon/violentmonkey/).
  2. Click the Violentmonkey extension icon in your toolbar to confirm that user scripts are allowed and active.

* **Microsoft Edge:**
  1. Install Violentmonkey from [Edge Add-ons](https://microsoftedge.microsoft.com/addons/detail/violentmonkey/eeagobfjdenkkddmbclomhiblgggliao).
  2. Open `edge://extensions` and enable **Developer mode**.

### Step 2: Install AMAES Toolkit
* Visit the **[AMAES Toolkit Installer Website](https://amaestoolkit.pages.dev/)** and click **Install AMAES Toolkit**, or install directly via the [UserScript Raw Link](https://raw.githubusercontent.com/Acads-Tools/amaes-toolkit/main/amaes-toolkit.user.js).
* In the Violentmonkey tab that opens, click the green **"Confirm installation"** button.

### Step 3: Open Moodle
* Navigate to your Moodle portal (e.g., **[semestral.amaes.com](https://semestral.amaes.com/)** or your term's specific portal path like `semestral.amaes.com/xxxx/`, such as `/2612/` depending on your current school year and semester) and log in.
* The toolkit panel will appear in the bottom-right corner of your screen.

### Step 4: (Optional) Setup Free Google Gemini AI
1. In the toolkit panel on Moodle, navigate to the **Course Tools** tab and expand **AI Assistant (Google Gemini)**.
2. Click **Setup Free AI Assistant**.
3. Follow the 4-step guide to get your free personal API key from [Google AI Studio](https://aistudio.google.com/app/apikey) (100% free with any standard Google account).
4. Paste your key and click **Test & Save Key**. The toolkit is now ready to assist with uncertain quiz questions automatically!

Shared AI fallback is enabled by default in the setup window. If Google temporarily rate-limits your personal key, the toolkit may try a small, project-managed pool so you do not have to wait. Your personal key is never uploaded to that pool. Shared capacity is limited; if it is full, the toolkit will explain what happened and let you retry or add another personal key. Disable **Use shared AI help if my key is temporarily busy** if you do not want this fallback.

---

<a id="keyboard-shortcuts"></a>

## Keyboard Shortcuts

| Key | Action |
| :--- | :--- |
| `Space` / `N` | Advance to Next Question / Page · Hasten Auto-Submit (-2s) on Summary |
| `[` / `]` | Cycle Previous / Next Quiz or Exam in Sequence |
| `P` | Pause / Resume Auto-Quiz & Auto-Submit Countdown |
| `C` | 1-Click Copy Formatted Question for AI |
| `V` | Paste AI Answer (Auto-Selects Matching Choice) |
| `F` | Toggle Fast Answer (Turbo) Mode |
| `1` – `4` / `A` – `D` | Select Choice Option 1 through 4 |
| `H` | Highlight Answers Immediately |
| `?` / `K` | Open Quick Guide & Shortcuts Modal |
| `Esc` | Close Modal / Minimize Toolkit Panel |

---

<a id="developer--contributing-guide"></a>

## Developer & Contributing Guide

Contributions, bug reports, and pull requests from students and developers are warmly welcomed.

### Technology Stack
* **Core Language:** Vanilla JavaScript (ES2022+ / Standard DOM APIs).
* **Architecture:** Modular component architecture in `src/` with zero runtime dependencies.
* **Styling & UI:** Pure CSS3 Variables, CSS Grid / Flexbox, SVG Vector Icons.
* **Serverless Relay:** Cloudflare Workers, Cloudflare D1 SQL database.
* **Automated Testing:** Deterministic Node.js VM suite (`tests/test_toolkit.js`) plus an opt-in live Jenny source integration test (`tests/test_jennysonline_live.js`).

### Reporting Bugs & Feature Requests
* **In-App 1-Click Bug Reporter:** While on Moodle, click the **Bug icon** (`#amaes-bug-btn`) in the toolkit header. Describe the issue, review attached sanitized logs, and submit directly to create a tracking issue.
* **GitHub Issues:** Open an issue via the [GitHub Issue Tracker](https://github.com/Acads-Tools/amaes-toolkit/issues).

### Modular Source Architecture & Building from Source
The repository is structured with clean domain modules in `src/` and an automated build pipeline:

```text
src/
├── meta.js              # Tampermonkey / Violentmonkey header block
├── init.js              # Lifecycle bootstrapper & DOM observers
├── core/                # Configuration, versioning & unified HTTP client
├── moodle/              # Question parsing, course & activity detectors
├── quiz/                # Autonomous solver & DOM event bindings
├── ai/                  # Gemini client, rate limiter & prompt formatter
├── sync/                # Auto-updater, study scraper & review harvester
├── ui/                  # Theme CSS, SVG icons, panel & modal HTML
└── dev/                 # Diagnostics log exporter & secret developer console
```

#### Build & Test Commands
Prerequisites: Node.js 18+.

```bash
# Clone the repository
git clone https://github.com/Acads-Tools/amaes-toolkit.git
cd amaes-toolkit

# Bundle src/ into distribution file amaes-toolkit.user.js
npm run build

# Run the deterministic regression suite (no external network required)
npm test

# Fetch and parse live Jenny Blogger posts/sheets for IT6205A and IT6206
npm run test:live:jenny

# Validate JavaScript syntax
npm run syntax
```

### Forking & Adapting for Other Moodle Portals

AMAES Toolkit is designed to be fully modular and adaptable to other institutions running standard Moodle 3.x or 4.x installations. If you want to fork this project and deploy it for your own university, college, or study group, follow these steps:

#### 1. Configure Portal Domain Matches
Open `src/meta.js` and update the `@match` headers to include your institution's Moodle URL:
```javascript
// @match        https://moodle.youruniversity.edu/*
// @match        https://portal.youruniversity.edu/*
```

#### 2. Update Repository & Service Constants
Open `src/core/config.js` and update the repository endpoints and portal links:
```javascript
const SCRIPT_RAW_URL = "https://raw.githubusercontent.com/YOUR_ORG/YOUR_REPO/main/amaes-toolkit.user.js";
const GITHUB_REPO_URL = "https://github.com/YOUR_ORG/YOUR_REPO";
const WEBSITE_URL = "https://your-domain.pages.dev/";
```
If your school's Moodle uses dynamic term path prefixes (such as `/term2026/`), adjust the regular expression in `getSemesterBasePath()` inside `src/core/config.js`.

#### 3. Standard Moodle DOM Compatibility
The toolkit uses universal Moodle CSS selectors located in `src/moodle/detector.js`:
* Question Blocks: `.que` (covering `.multichoice`, `.truefalse`, `.shortanswer`, `.match`, `.gapselect`)
* Question Formulations: `.formulation`, `.qtext`
* Choices & Options: `.answer > div`, `input[type="radio"]`, `input[type="checkbox"]`
* Navigation Buttons: `.mod_quiz-next-nav`, `input[name="next"]`, `.submitbtns`

These standard classes work natively across standard Moodle distributions. If your institution uses a customized Moodle theme that alters standard class names, you can customize the query selectors in `src/moodle/detector.js`.

#### 4. Build, Verify & Deploy
```bash
# Bundle your modules into root and public/ distribution files
npm run build

# Verify your build passes the unit test suite
npm test
```
The static installer portal in `public/` can be deployed for free in seconds using Cloudflare Pages (`npx wrangler pages deploy public --project-name your-project --branch main`) or GitHub Pages.

### Privacy & Contributor Rules
* **Mandatory Zero-PII Rule:** All commits must adhere strictly to anonymous project identity:
  ```bash
  git config user.name "AcademicContributor"
  git config user.email "academic-contributor@users.noreply.github.com"
  ```
* Automated CI enforces `.github/workflows/privacy-check.yml` on every pull request, blocking personal names, file paths, and private emails.

---

<a id="zero-telemetry--privacy-architecture"></a>

## Zero Telemetry & Privacy Architecture

Privacy is the foundational design requirement of AMAES Toolkit:

* **100% Client-Side Execution:** All question matching, solver algorithms, and option selection happen inside your browser tab.
* **Zero Account Tracking:** The toolkit has no analytics trackers, no Google Analytics, no Facebook pixels, and no telemetry pings.
* **Encrypted Relay:** When sharing confirmed review questions with the community consensus bank, questions are stripped of student identifiers, user IDs, timestamps, and cookies before transmission.

---

<a id="frequently-asked-questions"></a>

## Frequently Asked Questions

<details>
<summary><b>Clicking the install link just shows raw JavaScript code. What should I do?</b></summary>
<br>
This happens when a userscript manager is not yet installed in your browser. Install <a href="https://violentmonkey.github.io/">Violentmonkey</a> first, or visit the <a href="https://amaestoolkit.pages.dev/">Quick Install Site</a> which guides you through browser setup in one click.
</details>

<details>
<summary><b>Does this tool transmit any personal student data?</b></summary>
<br>
The toolkit does not collect student names, student IDs, email addresses, grades, cookies, or Moodle session tokens for telemetry, community answers, or study services. Account Switcher usernames and passwords are stored unencrypted in local userscript-manager storage and ordinarily submitted only to Moodle's login form. If you explicitly create a setup transfer, selected settings, account profiles, and Gemini API keys are encrypted in your browser and relayed as ciphertext; toolkit services cannot read the selected credentials. The code is the decryption secret; anyone with it can import the selected data. It does not expire, works once only, and the ciphertext is deleted on import. Never share the code publicly. Do not use saved credentials on a browser profile other people can access. Shared review reports contain anonymous question text, confirmed answer(s) when Moodle reveals them, and/or choices Moodle marked incorrect; submissions are validated before being merged into the shared database.
</details>

<details>
<summary><b>What happens when a question is not yet in the database?</b></summary>
<br>
The auto-solver safely pauses without advancing, displays a notice explaining that no verified answer is known yet, and allows you to review the question manually or use the AI clipboard shortcut. It never guesses blindly.
</details>

<details>
<summary><b>Why does Chrome require Developer Mode for userscripts?</b></summary>
<br>
Recent versions of Chromium (Google Chrome and Brave) require users to enable "Developer mode" under <code>chrome://extensions</code> in order for extensions like Violentmonkey to execute userscripts via the User Scripts API. This is a standard browser security requirement and only needs to be enabled once.
</details>

---

<a id="academic-integrity--liability-disclaimer"></a>

## Academic Integrity & Liability Disclaimer

> [!CAUTION]
> ### Important Institutional & Academic Integrity Notice
> AMAES Toolkit is developed and distributed solely as an assistive study companion, accessibility aid, and personal revision question repository.
> 
> * **The tool is provided "as is" for educational and accessibility purposes.** It is intended for concept revision, self-testing, and assistive navigation.
> * **The authors and contributors are not responsible for any academic penalties, account suspensions, or violations of institutional Terms of Service.** Users are solely responsible for ensuring that their use complies with their school's Student Handbook, Academic Honesty Policies, assessment guidelines, and Moodle portal rules.
> * **Users assume all risks associated with deploying automated scripts on institutional platforms.** The authors accept zero liability for any grade invalidations, academic sanctions, or disciplinary actions.
> * **No Institutional Affiliation:** AMAES Toolkit is an independent, unofficial open-source project. It is **not affiliated with, endorsed by, sponsored by, or operated by** AMA Education System (AMAES), AMA University, Moodle Pty Ltd, Violentmonkey, Tampermonkey, or any browser vendor.
> 
> The software is provided **"AS IS" and "AS AVAILABLE"** under the [MIT License](LICENSE), without warranty of any kind, express or implied. By installing or using this software, you assume all responsibility and risk associated with its use. Review the complete [Terms of Use](docs/TERMS.md) before installing.

---

**Links:** [GitHub Repository](https://github.com/Acads-Tools/amaes-toolkit) • [Quick Install Site](https://amaestoolkit.pages.dev/) • [Question Database](https://github.com/Acads-Tools/database) • [Terms of Use](docs/TERMS.md) • [Security Policy](SECURITY.md) • [Greasy Fork](https://greasyfork.org/en/scripts/594744-amaes-toolkit) • [Report a Bug / Request Feature](https://github.com/Acads-Tools/amaes-toolkit/issues)
